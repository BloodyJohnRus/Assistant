import subprocess, signal
def prnt(msg):
    print(msg)
class botManager():
    stat = False
    stat2 = False
    process = None
    process2 = None
    nms={}
    done={}
    plns={}
    def here(self, n):
        self.nms[n]="+"
    def verify(self, user, reson, pln):
        print("VRF")
        print(user)
        print(self.done)
        if user in self.nms:
            self.nms.pop(user)
            self.done[user]=reson
            self.plns[user]=pln
    def stopp(self):
        self.stat=False
        self.process.send_signal(signal.SIGTERM)
    def stop(self):
        self.stat=False
        self.process.send_signal(signal.SIGTERM)
    def status(self):
        print(self.stat)
        return self.stat
    def start(self):
        self.stat=True
        self.process = subprocess.Popen(["python", "bot__.py"], stdout=subprocess.PIPE, shell=False)
    def rest(self):
        self.stop()
        self.start()
    def stop_(self):
        self.stat2=False
        self.process2.send_signal(signal.SIGTERM)
    def status_(self):
        print(self.stat2)
        return self.stat2
    def start_(self):
        self.stat2=True
        self.process2 = subprocess.Popen(["python", "white_bot.py"], stdout=subprocess.PIPE, shell=False)
    def rest_(self):
        self.stop_()
        self.start_()
    def prnt(self, msg):
        print(msg)
    def init(self):
        self.start()
        self.start_()
mgr = botManager()