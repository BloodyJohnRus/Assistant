from telethon.sync import TelegramClient, events
from telethon.tl.custom import Button
import sqlite3, paymentManager
def button(text, id):
    return Button.inline(text, str(id).encode())
cnx = sqlite3.connect('djangodb')
cursor = cnx.cursor()
cursor.execute('SELECT * FROM "db_bot" WHERE const_id="black"')
black_bot = cursor.fetchone()
cursor.execute('SELECT * FROM "db_botdetails" WHERE const_id="black"')
black_desc = cursor.fetchone()
cursor.execute('SELECT * FROM "db_plansprice"')
prices = cursor.fetchall()
print(prices)
cnx.commit()
cnx.close()
BOT_TOKEN = black_bot[3]
bot = TelegramClient(black_bot[4], black_bot[1], black_bot[2])
bot.start(bot_token=BOT_TOKEN)
def btn_gen(price, user):
    return [[Button.url("Купить", paymentManager.mgr.mk_order("Probnik", price, user))], [button("Отмена", "ret")]]
btns = [[
        Button.inline("Тарифы🔥❤️", b"1")
    ],[
        Button.inline("За что я плачу🤍🤝", b"2")
    ]]
@bot.on(events.NewMessage(pattern="/start"))
async def chat_action(event):
    await event.respond("Приветствую вас в главном меню.", buttons=btns)
    snd=await event.get_sender()
    print(f"[C_EVENT] USER:{snd.username} MSG:{event.message}")
@bot.on(events.CallbackQuery())
async def two(event):
    snd=await event.get_sender()
    print(f"[BUTTON_EVENT] USER:{snd.username} ID=1")
    id = event.data
    if(id==b'1' or id==b'ret'):
        await event.respond(black_desc[3], buttons=[
            [button(f"1️⃣💘Пr0bNик🎒 - {prices[0][2]}₽", "3")],
            [button(f"2️⃣👱‍♀️OnlyFaнS👙 - {prices[1][2]}₽", '4')],
            [button(f"3️⃣🧒hentai loli👶 - {prices[2][2]}₽", '5')],
            [button(f"4️⃣🎗7-15 лет🎭 - {prices[3][2]}₽", '6')],
            [button(f"5️⃣🎒9-11 класс💌 - {prices[4][2]}₽",'7')],
            [button(f"6️⃣🤱5-10 лет🎒 - {prices[5][2]}₽", '8')],
            [button(f"7️⃣👗2-8 лет🍼 - {prices[6][2]}₽", '9')],
            [button(f"8️⃣🎢BIG PACK🎡 - {prices[7][2]}₽", '10')],
            [button(f"9️⃣👄👩‍❤️‍💋‍👩Ultra big pack👩🫦 - {prices[8][2]}₽", '11')],
            [button(f"🔟🔥👑ALL IN👑🔥 - {prices[9][2]}₽", '12')],
            [button("◄ Назад", '13')]])
    if id==b'3':
        await event.respond("Вы выбрали план 1️⃣💘Пr0bNик🎒\nВы действительно хотите его купить?",
                            buttons=btn_gen(prices[0][2], snd.username))
    if id==b'4':
        await event.respond("Вы выбрали план 2️⃣👱‍♀️OnlyFaнS👙\nВы действительно хотите его купить?",
                            buttons=btn_gen(prices[1][2], snd.username))
    if id==b'5':
        await event.respond("Вы выбрали план 3️⃣🧒hentai loli👶\nВы действительно хотите его купить?",
                            buttons=btn_gen(prices[2][2], snd.username))
    if id==b'6':
        await event.respond("Вы выбрали план 4️⃣🎗7-15 лет🎭\nВы действительно хотите его купить?",
                            buttons=btn_gen(prices[3][2], snd.username))
    if id==b'7':
        await event.respond("Вы выбрали план 5️⃣🎒9-11 класс💌\nВы действительно хотите его купить?",
                            buttons=btn_gen(prices[4][2], snd.username))
    if id==b'8':
        await event.respond("Вы выбрали план 6️⃣🤱5-10 лет🎒\nВы действительно хотите его купить?",
                            buttons=btn_gen(prices[5][2], snd.username))
    if id==b'9':
        await event.respond("Вы выбрали план 7️⃣👗2-8 лет🍼\nВы действительно хотите его купить?",
                            buttons=btn_gen(prices[6][2], snd.username))
    if id==b'10':
        await event.respond("Вы выбрали план 8️⃣🎢BIG PACK🎡\nВы действительно хотите его купить?",
                            buttons=btn_gen(prices[7][2], snd.username))
    if id==b'11':
        await event.respond("Вы выбрали план 9️⃣👄👩‍❤️‍💋‍👩Ultra big pack👩🫦\nВы действительно хотите его купить?",
                            buttons=btn_gen(prices[8][2], snd.username))
    if id==b'12':
        await event.respond("Вы выбрали план 🔟🔥👑ALL IN👑🔥\nВы действительно хотите его купить?",
                            buttons=btn_gen(prices[9][2], snd.username))
    if id==b'13':
        await event.respond("Приветствую вас в главном меню.", buttons=btns)
#TODO:TRFF BUTTONS

bot.run_until_disconnected()