from django.contrib import admin
from .models import Users, Bot, BotDetails, PlansPrice, ShopInfo

admin.site.register(Users)
admin.site.register(Bot)
admin.site.register(BotDetails)
admin.site.register(PlansPrice)
admin.site.register(ShopInfo)
