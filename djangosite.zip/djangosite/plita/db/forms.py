from .models import Users, Bot, BotDetails, PlansPrice
from django.forms import ModelForm, Textarea , TextInput,  DateTimeInput, NumberInput, Select
from datetime import date
dat = date.today()
class UsersForm(ModelForm):
    class Meta:
        model = Users
        fields = ["telegram", "data", "plan", "price"]
        widgets = {
            'telegram': TextInput(attrs={
                'class': 'fake_input',
                'placeholder': 'Telegram',
            }),
            'data': DateTimeInput(attrs={
                'class': 'fake_input',
                'type': 'date',
                'placeholder': dat.strftime('%d.%m.%Y'),
            }),
            'plan': TextInput(attrs={
                'class': 'fake_input',
                'placeholder': 'Plan',
            }),
            'price': NumberInput(attrs={
                'class': 'fake_input',
                'placeholder': 'Price',
            })
        }
class BotForm(ModelForm):
    class Meta:
        model = Bot
        fields = ["api_id", "hash_api", "bot_token", "name"]
        if len(Bot.objects.all().values())>0:
            api=Bot.objects.get(const_id="black").api_id
            hash_=Bot.objects.get(const_id="black").hash_api
            token=Bot.objects.get(const_id="black").bot_token
            na=Bot.objects.get(const_id="black").name
        widgets = {
            'api_id': TextInput(attrs={
                'class': 'fake_input',
                'placeholder': 'API_ID',
                'value': api,
            }),
            'hash_api': TextInput(attrs={
                'class': 'fake_input',
                'placeholder': 'API_HASH',
                'value': hash_
            }),
            'bot_token': TextInput(attrs={
                'class': 'fake_input',
                'placeholder': 'Токен бота',
                'value': token
            }),
            'name': TextInput(attrs={
                'class': 'fake_input',
                'placeholder': 'Имя сессии',
                'value': na
            })
        }
class DetailsForm(ModelForm):
    class Meta:
        det_data = BotDetails.objects.get(const_id="black")
        model = BotDetails
        fields = ["screen", "plans", "support", "pay_info"]
        widgets = {
            'screen': Textarea(attrs={
                'class': 'fake_input2',
                'placeholder': 'Описание скриншотов',
                'value': det_data.screen
            }),
            'plans': Textarea(attrs={
                'class': 'fake_input2',
                'placeholder': 'Описание тарифов',
                'value': det_data.plans
            }),
            'support': Textarea(attrs={
                'class': 'fake_input2',
                'placeholder': 'Описание поддержки',
                'value': det_data.support
            }),
            'pay_info': Textarea(attrs={
                'class': 'fake_input2',
                'placeholder': 'Описание "за что вы платите"',
                'value': det_data.pay_info
            })
        }
class PlansForm(ModelForm):
    class Meta:
        model=PlansPrice
        fields=['name', 'price']
        widgets = {
            'name': Select(attrs={
                'class': 'fake_input3',
                'placeholder': 'Имя'
            }),
            'price': NumberInput(attrs={
                'class': 'fake_input3',
                'placeholder': 'Цена'
            })
        }