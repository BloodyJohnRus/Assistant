from django.db import models
from datetime import date

class Users(models.Model):
    telegram=models.CharField('Телеграм пользователя', max_length=64, default='')
    data=models.DateTimeField('Время покупки', max_length=64, default=date.today())
    plan=models.CharField('План', max_length=64, default='')
    price=models.IntegerField("Цена", default=199)
    def __str__(self):
        return self.telegram
    class Meta:
        verbose_name = "БД Пользователей(<1)"
        verbose_name_plural = "БД Пользователей(>1)"

class Bot(models.Model):
    api_id=models.CharField('API_ID', max_length=8, default='')
    hash_api=models.CharField('BOT_API_HASH', max_length=641, default='')
    bot_token=models.CharField('Токен', max_length=614, default='')
    name=models.CharField('Имя', max_length=32, default='')
    const_id=models.CharField('BOT_SELF_ID', max_length=8,default='')
    def __str__(self):
        return self.name
    class Meta:
        verbose_name = "БД Ботов"
        verbose_name_plural = "БД Ботов"
class BotDetails(models.Model):
    const_id=models.CharField('ID', max_length=8)
    screen=models.CharField('Информация для скриншотов', max_length=2048, default='')
    plans=models.CharField('Информация про планы', max_length=2048, default='')
    support=models.CharField('Информация про поддержку', max_length=2048, default='')
    pay_info=models.CharField('Информация "за что я плачу"', max_length=2048, default='')
    def __str__(self):
        return self.plans
    class Meta:
        verbose_name = "Бот-инфа"
        verbose_name_plural = "Бот-инфа"
class PlansPrice(models.Model):
    select = ((
        '0', '1️⃣💘Пr0bNик🎒'
    ),(
        '1', '2️⃣👱‍♀️OnlyFaнS👙'
    ),(
        '2', '3️⃣🧒hentai loli👶'
    ),(
        '3', '4️⃣🎗7-15 лет🎭'
    ),(
        '4', '5️⃣🎒9-11 класс💌'
    ),(
        '5', '6️⃣🤱5-10 лет🎒'
    ),(
        '6', '7️⃣👗2-8 лет🍼'
    ),(
        '7', '8️⃣🎢BIG PACK🎡'
    ),(
        '8', '9️⃣👄👩‍❤️‍💋‍👩Ultra big pack👩🫦'
    ),(
        '9', '🔟🔥👑ALL IN👑🔥'
    ))
    name=models.CharField('Имя', max_length=2048, choices=select)
    price=models.IntegerField('Цена')
    def __str__(self):
        return self.name
class ShopInfo(models.Model):
    merchant_id=models.CharField("Айди магазина", max_length=256)
    api_key=models.CharField('API-ключ пользователя',max_length=256)
    secret1=models.CharField('Секретное слово 1',max_length=2048)
    secret2=models.CharField('Секретное слово 2',max_length=2048)
    def __str__(self):
        return self.merchant_id
    class Meta:
        verbose_name="Shop Info"
        verbose_name_plural="Shop Info"