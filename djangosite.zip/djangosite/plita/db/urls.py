from django.urls import path
from . import views
urlpatterns = [
    path('', views.history, name='history'),
    path('create_fake', views.create_fake, name="create_fake"),
]