from django.shortcuts import render, redirect
from .models import Users
from .forms import UsersForm
import botManager
color='color: black;'
if botManager.mgr.status():
    color='color: white;'
color2='color: black;'
if botManager.mgr.status_():
    color_='color: white;'
users = Users.objects.all().order_by('-data').values()[:5]
def history(request):
    color='color: black;'
    if botManager.mgr.status():
        color='color: white;'
    color2='color: black;'
    if botManager.mgr.status_():
        color2='color: white;'
    return render(request, 'db/history.html', {'users':users, 'color':color, 'color_':color2, 'color__': f'linear-gradient(135deg, {color[6:12]} 0%, {color2[6:12]} 75%)'})
def create_fake(request):
    error=''
    color='color: black;'
    color2='color: black;'
    if botManager.mgr.status():
        color='color: white;'
    if botManager.mgr.status_():
        color2='color: white;'
    if request.method=='POST':
        form = Users(request.POST)
        if form.is_valid():
            form.save()
            return render(request, 'db/history.html', {'color': color, 'color_':color2, 'color__': f'linear-gradient(135deg, {color[6:12]} 0%, {color2[6:12]} 75%)'})
        else:
            error='Неверная форма!'
    form = UsersForm()
    data={
        'form': form,
        'error': error,
        'color': color,
        'color_':color2,
        'color__': f'linear-gradient(135deg, {color[6:12]} 0%, {color2[6:12]} 75%)'
    }
    return render(request, 'db/create_fake.html', data)
