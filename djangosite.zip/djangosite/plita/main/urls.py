from django.urls import path
from . import views
urlpatterns = [
    path('', views.index, name='index'),
    path('stats', views.stats, name="stats"),
    path('history', views.history, name="history"),
    path('settings', views.settings, name="settings"),
    path('settingsWhite', views.settings_, name="settingsWhite"),
    path('power', views.power, name="power"),
    path('priceEdit', views.priceEdit, name="priceEdit"),
    path('dark_description', views.dark_description, name="dark_description"),
    path('create_fake', views.create_fake, name="create_fake"),
]