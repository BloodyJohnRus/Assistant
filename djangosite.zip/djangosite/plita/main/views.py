from django.shortcuts import render
from db.models import Users, Bot, BotDetails, PlansPrice
from db.forms import UsersForm, BotForm, DetailsForm, PlansForm
from django.http import HttpResponse
from datetime import date
import paymentManager
import botManager
botManager.mgr.init()
users = Users.objects.all().order_by('-data').values()[:5]
prices = Users.objects.all().values()
all = 0
today = 0
d1 = date.today().strftime("%d.%m.%Y")
userProfit = dict()
color='color: black;'
color2='color: black;'
if botManager.mgr.status():
    color='color: white;'
if botManager.mgr.status_():
    color2='color: white;'
for user in prices:
    userProfit.update({user['telegram']:0})
    userProfit[user['telegram']]+=user['price']
    all+=user['price']
    if(user['data'].strftime("%d.%m.%Y").startswith(d1)):
        today+=user['price']
def index(request):
    color='color: black;'
    color2='color: black;'
    if botManager.mgr.status():
        color='color: white;'
    if botManager.mgr.status_():
        color2='color: white;'
    print(f'linear-gradient(135deg, {color[6:12]} 0%, {color2[6:12]} 75%)')
    return render(request, 'main/index.html', {'color': color, 'color__': f'linear-gradient(135deg, {color[6:12]} 0%, {color2[6:12]} 75%)', 'color_': color2})
def stats(request):
    userProf=userProfit
    color='color: black;'
    color2='color: black;'
    if botManager.mgr.status():
        color='color: white;'
    if botManager.mgr.status_():
        color2='color: white;'
    top = '---'
    if len(userProfit)>0:
        top = max(userProf, key=userProf.get)
    if type(top) != int:
        userProf={'---':'0'}
    st = paymentManager.mgr.get_b()
    sttus = botManager.mgr.status()
    if(sttus):
        sttus="Включен"
    else:
        sttus="Выключен"
    return render(request, 'main/stats.html', {'users': users, 'sum': all, 'mostProfit': top, 'most': userProf[top], 'today': today, 'color': color, 'color__': f'linear-gradient(135deg, {color[6:12]} 0%, {color2[6:12]} 75%)', 'color_': color2, 'bal': st['balance'], 'userscount': f"{len(Users.objects.all())}", 'sttus': sttus})
def settings(request):
    color='color: black;'
    color2='color: black;'
    if botManager.mgr.status():
        color='color: white;'
    if botManager.mgr.status_():
        color2='color: white;'
    bots = Bot.objects.all().values()
    error=''
    if request.method=='POST':
        form = BotForm(request.POST)
        cdata = request.POST
        dark_bot=Bot.objects.get(const_id="black")
        print("DARK:")
        print(dark_bot)
        if form.is_valid():
            obj = dark_bot
            if not obj:
                obj = Bot.objects.all().get(const_id="black")
            obj.api_id = cdata["api_id"]
            obj.hash_api = cdata["hash_api"]
            obj.bot_token = cdata["bot_token"]
            obj.name = cdata["name"]
            obj.save(update_fields=['api_id', 'hash_api', 'bot_token', 'name'])
            form = BotForm(request.POST)
            botManager.mgr.rest()
            error='Успешно!'
            return render(request, 'main/settings.html', {'botform': form, 'error': error, 'bots': Bot.objects.all().values(), 'color': color, 'color__': f'linear-gradient(135deg, {color[6:12]} 0%, {color2[6:12]} 75%)', 'color_': color2})
        else:
            error='Неверная форма!'
    form=BotForm()
    return render(request, 'main/settings.html', {'botform': form, 'error': error, 'bots': bots, 'color': color, 'color__': f'linear-gradient(135deg, {color[6:12]} 0%, {color2[6:12]} 75%)', 'color_': color2})
def settings_(request):
    color='color: black;'
    color2='color: black;'
    if botManager.mgr.status():
        color='color: white;'
    if botManager.mgr.status_():
        color2='color: white;'
    bots = Bot.objects.all().values()
    error=''
    if request.method=='POST':
        form = BotForm(request.POST)
        cdata = request.POST
        dark_bot=Bot.objects.get(const_id="white")
        print("WHITE:")
        print(dark_bot)
        if form.is_valid():
            obj = dark_bot
            if not obj:
                obj = Bot.objects.all().get(const_id="white")
            obj.api_id = cdata["api_id"]
            obj.hash_api = cdata["hash_api"]
            obj.bot_token = cdata["bot_token"]
            obj.name = cdata["name"]
            obj.save(update_fields=['api_id', 'hash_api', 'bot_token', 'name'])
            form = BotForm(request.POST)
            botManager.mgr.rest_()
            error='Успешно!'
            return render(request, 'main/settingsWhite.html', {'botform': form, 'error': error, 'bots': Bot.objects.all().values(), 'color': color, 'color__': f'linear-gradient(135deg, {color[6:12]} 0%, {color2[6:12]} 75%)', 'color_': color2})
        else:
            error='Неверная форма!'
    form=BotForm()
    return render(request, 'main/settingsWhite.html', {'botform': form, 'error': error, 'bots': bots, 'color': color, 'color__': f'linear-gradient(135deg, {color[6:12]} 0%, {color2[6:12]} 75%)', 'color_': color2})
def history(request):
    color='color: black;'
    color2='color: black;'
    if botManager.mgr.status():
        color='color: white;'
    if botManager.mgr.status_():
        color2='color: white;'
    return render(request, 'db/history.html', {'users':users, 'color': color, 'color__': f'linear-gradient(135deg, {color[6:12]} 0%, {color2[6:12]} 75%)', 'color_': color2})
def create_fake(request):
    color='color: black;'
    color2='color: black;'
    if botManager.mgr.status():
        color='color: white;'
    if botManager.mgr.status_():
        color2='color: white;'
    form = UsersForm()
    data={
        'form': form, 'color': color, 'color__': f'linear-gradient(135deg, {color[6:12]} 0%, {color2[6:12]} 75%)', 'color_': color2
    }
    return render(request, 'db/create_fake.html', data)
def dark_description(request):
    color='color: black;'
    color2='color: black;'
    if botManager.mgr.status():
        color='color: white;'
    if botManager.mgr.status_():
        color2='color: white;'
    error = ''
    form = DetailsForm()
    detail = BotDetails.objects.get(const_id="black")
    dat=["", "", "", ""]
    dat[0]=detail.screen
    dat[1]=detail.plans
    dat[2]=detail.support
    dat[3]=detail.pay_info
    if(request.method=="POST"):
        form=DetailsForm(request.POST)
        data=request.POST
        if(form.is_valid()):
            error='Успешно!'
            print(len(BotDetails.objects.all()))
            if len(BotDetails.objects.all().values())>0:
                detail = BotDetails.objects.get(const_id="black")
                detail.screen=data["screen"]
                dat[0]=detail.screen
                detail.plans=data["plans"]
                dat[1]=detail.plans
                detail.support=data["support"]
                dat[2]=detail.support
                detail.pay_info=data["pay_info"]
                dat[3]=detail.pay_info
                botManager.mgr.rest()
                detail.save(update_fields=['screen', 'plans', 'support', 'pay_info'])
            else:
                form.save()
            return render(request, 'main/dark_description.html', {'form': form, 'error': error, 'color': color, 'color__': f'linear-gradient(135deg, {color[6:12]} 0%, {color2[6:12]} 75%)', 'color_': color2, 'screen': dat[0], 'plans': dat[1], 'support': dat[2], 'pay_info': dat[3]})
        else:
            error='Неверная форма!'
    return render(request, 'main/dark_description.html', {'form': form, 'error': error, 'color': color, 'color__': f'linear-gradient(135deg, {color[6:12]} 0%, {color2[6:12]} 75%)', 'color_': color2, 'screen': dat[0], 'plans': dat[1], 'support': dat[2], 'pay_info': dat[3]})
def about(request):
    return HttpResponse("<h1 style='color: red;'>About!</h4>")
def power(request):
    #w
    color='color: black;'
    error='выключен.'
    color2='color: black;'
    if botManager.mgr.status():
        color='color: white;'
        error='включен.'
    if botManager.mgr.status_():
        color2='color: white;'
    if(request.method=='POST'):
        print(request.POST)
        if 'black' in request.POST:
            if botManager.mgr.status():
                color='color: black;'
                error='выключен.'
                botManager.mgr.stop()
            else:
                color='color: white;'
                error='включен.'
                botManager.mgr.start()
        else:
            if botManager.mgr.status_():
                color2='color: black;'
                botManager.mgr.stop_()
            else:
                color2='color: white;'
                botManager.mgr.start_()
    return render(request, 'main/power.html', {'color': color, 'color__': f'linear-gradient(135deg, {color[6:12]} 0%, {color2[6:12]} 75%)', 'color_': color2, 'error': error})
def priceEdit(request):
    form = PlansForm()
    color='color: black;'
    error=''
    color2='color: black;'
    if botManager.mgr.status():
        color='color: white;'
        error='включен.'
    if botManager.mgr.status_():
        color2='color: white;'
    if(request.method=='POST'):
        print(request.POST)
        form=PlansForm(request.POST)
        if(form.is_valid()):
            data= request.POST
            obj = PlansPrice.objects.get(name=data['name'])
            obj.price=int(data['price'])
            obj.save(update_fields=['price'])
            error='Успешно!'
            return render(request, 'main/priceEdit.html', {'form': form, 'error': error, 'color': color, 'color__': f'linear-gradient(135deg, {color[6:12]} 0%, {color2[6:12]} 75%)', 'color_': color2, 'prices': PlansPrice.objects.all()})
        else:
            error="Произошла ошибка!"
            return render(request, 'main/priceEdit.html', {'form': form, 'error': error, 'color': color, 'color__': f'linear-gradient(135deg, {color[6:12]} 0%, {color2[6:12]} 75%)', 'color_': color2, 'prices': PlansPrice.objects.all()})
    return render(request, 'main/priceEdit.html', {'form': form, 'error': error, 'color': color, 'color__': f'linear-gradient(135deg, {color[6:12]} 0%, {color2[6:12]} 75%)', 'color_': color2, 'prices': PlansPrice.objects.all()})
def receiptNotif(request):
    if request.method==request.POST:
        print(request.POST)
    print("Not receipt!")
class getData():
    select = ((
        '0', '1️⃣💘Пr0bNик🎒'
    ),(
        '1', '2️⃣👱‍♀️OnlyFaнS👙'
    ),(
        '2', '3️⃣🧒hentai loli👶'
    ),(
        '3', '4️⃣🎗7-15 лет🎭'
    ),(
        '4', '5️⃣🎒9-11 класс💌'
    ),(
        '5', '6️⃣🤱5-10 лет🎒'
    ),(
        '6', '7️⃣👗2-8 лет🍼'
    ),(
        '7', '8️⃣🎢BIG PACK🎡'
    ),(
        '8', '9️⃣👄👩‍❤️‍💋‍👩Ultra big pack👩🫦'
    ),(
        '9', '🔟🔥👑ALL IN👑🔥'
    ))
    name=''
    def __init__(self, id):
        self.name = self.select[str(id)]
    def get_all(self):
        all=list()
        for i in range(9):
            all.append(self.select(str(i)))
        return all
    def get(self, id):
        return getData(str(id))