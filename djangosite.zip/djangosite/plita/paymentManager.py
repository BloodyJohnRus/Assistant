import requests
import hashlib, sqlite3
from urllib.parse import urlencode
from requests.exceptions import ConnectTimeout, ReadTimeout
from botManager import mgr
import random
import string
cnx = sqlite3.connect('djangodb')
cursor = cnx.cursor()
cursor.execute('SELECT * FROM "db_shopinfo"')
desc = cursor.fetchone()
cnx.commit()
cnx.close()
print(desc)
shop=desc[1]
key = desc[2]
secret1=desc[3]
secret2=desc[4]
url_pi='https://aaio.io/api/'
url_shop='https://aaio.io/merchant/pay?'
currency="RUB"
headers = {
    'Accept': 'application/json',
    'X-Api-Key': key
}
def get_rnd(length):
    # choose from all lowercase letter
    letters = string.ascii_lowercase
    result_str = ''.join(random.choice(letters) for i in range(length))
    print("Random string of length", length, "is:", result_str)
    return result_str
class paymentManager():
    verifyBuy={}
    myMgr = mgr
    def mk_user(self, user, pln):
        keys = self.verifyBuy
        if user in keys:
            print("IN")
        else:
            print("PLUS")
            self.verifyBuy[user]=pln
    def del_user(self, user):
        keys = self.verifyBuy
        if user in keys:
            self.verifyBuy.pop(user)
            print("Deleted")
    def isOrderDone(self, order):
        params = {
            'merchant_id': shop,
            'order_id': order
        }
        try:
            response = requests.post(url_pi+"info-pay", data=params, headers=headers, timeout=(15, 60))
        except ConnectTimeout:
            print('ConnectTimeout')
            return False
        except ReadTimeout:
            print('ReadTimeout')
            return False
        if(response.status_code in [200, 400, 401]):
            try:
                response_json = response.json()
                if(response_json['status'] == 'success'):
                    return True # Вывод результата
                else:
                    return False
            except:
                print()
                return False
    def send_response(self, posturl):
        try:
            response = requests.post(url_pi+posturl, headers=headers, timeout=(15, 60))
        except ConnectTimeout:
            return {'balance':0}
        except ReadTimeout:
            return {'balance':0}
        if(response.status_code in [200, 400, 401]):
            try:
                response_json = response.json() # Парсинг результата
            except:
                return {'balance':0}

            if(response_json['type'] == 'success'):
                return (response_json) # Вывод результата
            else:
                return {'balance':0}
        else:
            return ('Response code: ' + str(response.status_code)) # Вывод неизвестного кода ответа
    def get_b(self):
        try:
            return self.send_response("balance")
        except:
            return {'balance':0}
    def mk_order(self, order_id, price, name):
        lang='ru'
        sign = f':'.join([
            str(shop),
            str(price),
            str(currency),
            str(secret1),
            str(order_id)
        ])
        params = {
            'merchant_id': shop,
            'amount': price,
            'currency': currency,
            'order_id': order_id,
            'sign': hashlib.sha256(sign.encode('utf-8')).hexdigest(),
            'desc': name,
            'lang': lang
        }
        print(url_shop + urlencode(params))
        return url_shop + urlencode(params)
    def get_order(self, n):
        return url_shop+n
mgr = paymentManager()