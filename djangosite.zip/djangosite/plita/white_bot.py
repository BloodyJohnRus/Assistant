from telethon.sync import TelegramClient, events
from telethon.tl.custom import Button
import sqlite3, paymentManager
def button(text):
    return Button.text(text, resize=True, single_use=False)
cnx = sqlite3.connect('djangodb')
print(cnx)
cursor = cnx.cursor()
cursor.execute('SELECT * FROM "db_bot" WHERE const_id="white"')
black_bot = cursor.fetchone()
cursor.execute('SELECT * FROM "db_botdetails" WHERE const_id="white"')
black_desc = cursor.fetchone()
cursor.execute('SELECT * FROM "db_plansprice"')
prices = cursor.fetchall()
print(prices)
cnx.commit()
cnx.close()
BOT_TOKEN = black_bot[3]
bot = TelegramClient(black_bot[4], black_bot[1], black_bot[2])
bot.start(bot_token=BOT_TOKEN)
@bot.on(events.NewMessage())
async def chat_action(event):
    snd=await event.get_sender()
@bot.on(events.NewMessage(pattern="/start"))
async def chat_action(event):
    await event.respond("Приветствую вас в главном меню.", buttons=([[
        Button.text("Купить одежду", resize=True, single_use=False),
        button("Поддержка")
    ],[
        button("Где берется товар"),
        button("Доставка")
    ]]))
@bot.on(events.NewMessage(pattern="Поддержка"))
async def chat_action(event):
    await event.respond("Наши контакты за адресом доставки:", buttons=([[button("◄ Назад")]]))
    await event.respond("Телеграм:", buttons=[[Button.url("Телеграм", "t.me/SellodeshaRUSSIA")]])
@bot.on(events.NewMessage(pattern="Доставка"))
async def chat_action(event):
    await event.respond("""Доставка осуществляется через Почту России на протяжении 1-3 рабочих дней.
Для того, чтобы мы смогли отправить вам товар, вы должны выполнить следующие шаги:
 1) Перейдите в раздел \"Поддержка\". Там вы сможете связаться с нами по Telegram.
 2) В поддержку напишите следующее:
   - ФИО
   - Телефон
   - Адрес доставки
 3) Также прикрепите скриншот вашего выигрыша.
 4) Ожидайте номер посылки от поддержи.
Желаем удачи вам!""", buttons=([[button("◄ Назад")]]))
@bot.on(events.NewMessage(pattern="◄ Назад"))
async def chat_action(event):
    await event.respond("Приветствую вас в главном меню.", buttons=([[
        Button.text("Купить одежду", resize=True, single_use=False),
        button("Поддержка")
    ],[
        button("Где берется товар"),
        button("Доставка")
    ]]))
@bot.on(events.NewMessage(pattern="Купить одежду"))
async def two(event):
    await event.respond(black_desc[3], buttons=[[button("◄ Назад")],[
        button("4 пары носков"),
        button("Шапка+балаклава"),
        button("Перчатки"),
        button("Футболка")],
        [button("Куртка"),
        button("Термобельё"),
        button("Худи")],
        [button("Ботинки зимние"),
        button("Толстовка"),
        button("Набор: куртка+термобельё+ботинки")
        ]])

@bot.on(events.NewMessage(pattern="Где берется товар"))
async def twor(event):
    msg="""Все товары мы закупаем на данных сайтах.
                        \nПосле того, как вы купили товар, бот случайным образом определяет вашу вещь.
                        \nПосле того, как вы увидели, какой вам товар выпал, вам остается написать нам в поддержку адрес доставки и ваш пол.
                        \nСсылки:
https://www.ozon.ru/product/komplekt-noskov-redmos-10-par-1207288706/
https://www.ozon.ru/product/shapka-1140865629/
https://www.ozon.ru/product/balaklava-877440169/
https://www.wildberries.ru/catalog/16958048/detail.aspx
https://www.ozon.ru/product/perchatki-1274640092/ 
https://www.ozon.ru/product/futbolka-fosfor-1-sht-849603165
https://www.ozon.ru/product/futbolka-revati-1-sht-860750837/ 
https://www.ozon.ru/product/kurtka-1302315644/
https://www.ozon.ru/product/parka-winter-bear-1328589668/
https://megamarket.ru/catalog/details/komplekt-termobelya-icewind-muzhskoy-cvet-seryy-razmer-48-100045851881_17217/
https://megamarket.ru/catalog/details/termobele-zhenskoe-dzhemper-legginsy-cvet-chernyy-goluboy-razmer-48-100045851785_77543/
https://www.ozon.ru/product/hudi-niti-niti-1124902832/
https://www.ozon.ru/product/hudi-monogamy-1249262802/
https://www.ozon.ru/product/botinki-patrol-1159280278
https://www.rendez-vous.ru/catalog/female/botinki/marco_tozzi_2_2_25260_29_chernyy-3209028/
https://www.ozon.ru/product/hudi-mother-russia-1191741861/
https://www.wildberries.ru/catalog/15445452/detail.aspx"""
    await event.respond(msg, buttons=[[button("◄ Назад")]])
@bot.on(events.NewMessage(pattern="Отмена"))
async def two(event):
    await event.respond(black_desc[3], buttons=[[button("◄ Назад")],[
        button("4 пары носков"),
        button("Шапка+балаклава"),
        button("Перчатки"),
        button("Футболка")],
        [button("Куртка"),
        button("Термобельё"),
        button("Худи")],
        [button("Ботинки зимние"),
        button("Толстовка"),
        button("Набор: куртка+термобельё+ботинки")
        ]])
#await bot.send_file(sender, "s")
"""
@bot.on(events.NewMessage(pattern="b"))
async def buy_confirm(event):
    string = prices[0][2]
    await event.respond(f"Вы выбрали: b \nЦена: {string} руб. Вы действительно хотите купить это?", buttons=[[button("Отмена")]])
    await event.respond("Если да, нажмите данную кнопку:", buttons=[[Button.url("Купить",paymentManager.mgr.get_order("b"))]]) """
@bot.on(events.NewMessage())
async def buy_confirm(event):
    sender = await event.get_sender()
    print(f"Someone pressed {event.raw_text}! It's {sender.username}")
    if event.raw_text=="4 пары носков":
        string = prices[0][2]
        await event.respond(f"Вы выбрали: 4 пары носков \nС него вы можете получить:\n - 1-4 пары носков\n Цена: {string} руб. Вы действительно хотите купить это?", buttons=[[button("Отмена")]])
        await bot.send_file(sender, "https://ir-1.ozone.ru/s3/multimedia-d/wc1000/6816720901.jpg")
        await event.respond("Если да, нажмите данную кнопку:", buttons=[[Button.url("Купить",paymentManager.mgr.mk_order("probnik", 149, event.username))]])
    if event.raw_text=="Шапка+балаклава":
        string = prices[1][2]
        await event.respond(f"Вы выбрали: Шапка+балаклава \nС него вы можете получить: \n - 1-4 пары носков \n - Шапка \n - Балаклава\n - Набор: шапка с балаклавой \nЦена: {string} руб. Вы действительно хотите купить это?", buttons=[[button("Отмена")]])
        await bot.send_file(sender, ["https://ir-1.ozone.ru/s3/multimedia-e/wc1000/6829534382.jpg"
                            ,"https://ir-1.ozone.ru/s3/multimedia-1/wc1000/6579072145.jpg"])
        await event.respond("Если да, нажмите данную кнопку:", buttons=[[Button.url("Купить",paymentManager.mgr.get_order("b"))]])
    if event.raw_text=="Перчатки":
        string = prices[2][2]
        await event.respond(f"Вы выбрали: Перчатки \n С него вы можете получить:\n - 1-4 пары носков\n - Шапка\n - Балаклава\n - Набор: шапка+балаклава\n - Перчатки\n - Бонус: Перчатки+рандомная вещь\nЦена: {string} руб. Вы действительно хотите купить это?", buttons=[[button("Отмена")]])
        await bot.send_file(sender, ["https://i.imgur.com/hK93LvE.png",
                                    "https://ir-1.ozone.ru/s3/multimedia-f/wc1000/6844924383.jpg"])
        await event.respond("Если да, нажмите данную кнопку:", buttons=[[Button.url("Купить",paymentManager.mgr.get_order("b"))]])
    if event.raw_text=="Футболка":
        string = prices[3][2]
        await event.respond(f"Вы выбрали: Футболка \nС него вы можете получить:\n - Одежда из раздела \"Перчатки\"\n - \"Перчатки\"+футболка\n - \"Перчатки\"+футболка+шапка\n Цена: {string} руб. Вы действительно хотите купить это?", buttons=[[button("Отмена")]])
        await bot.send_file(sender, ["https://ir-1.ozone.ru/s3/multimedia-v/wc1000/6658613203.jpg",
                            "https://ir-1.ozone.ru/s3/multimedia-1/wc1000/6568505953.jpg"])
        await event.respond("Если да, нажмите данную кнопку:", buttons=[[Button.url("Купить",paymentManager.mgr.get_order("b"))]])
    if event.raw_text=="Куртка":
        string = prices[4][2]
        await event.respond(f"Вы выбрали: Куртка \nС него вы можете получить:\n - Одежда из раздела \"Футболка\"\n - Футболка+куртка\nЦена: {string} руб. Вы действительно хотите купить это?", buttons=[[button("Отмена")]])
        await bot.send_file(sender, ["https://ir-1.ozone.ru/s3/multimedia-0/wc1000/6838226892.jpg",
                                    "https://ir-1.ozone.ru/s3/multimedia-5/wc1000/6797395949.jpg"])
        await event.respond("Если да, нажмите данную кнопку:", buttons=[[Button.url("Купить",paymentManager.mgr.get_order("b"))]])
    if event.raw_text=="Термобельё":
        string = prices[5][2]
        await event.respond(f"Вы выбрали: Термобельё \nС него вы можете получить:\n - Одежда из раздела \"Куртка\"\n - Термобельё+куртка\n - Термобельё+перчатки\n - Термобельё+куртка+перчатки\n Цена: {string} руб. Вы действительно хотите купить это?", buttons=[[button("Отмена")]])
        await bot.send_file(sender, ["https://main-cdn.sbermegamarket.ru/big2/hlr-system/-15/264/512/534/510/52/100045851881b0.jpg",
                                    "https://main-cdn.sbermegamarket.ru/big2/hlr-system/-15/273/709/308/302/337/100045851785b0.jpg"])
        await event.respond("Если да, нажмите данную кнопку:", buttons=[[Button.url("Купить",paymentManager.mgr.get_order("b"))]])
    if event.raw_text=="Худи":
        string = prices[6][2]
        await event.respond(f"Вы выбрали: Худи \nС него вы можете получить:\n - Одежда из раздела \"Термобельё\"\n - Худи\n - Худи + случайный предмет из раздела \"Термобельё\"\nЦена: {string} руб. Вы действительно хотите купить это?", buttons=[[button("Отмена")]])
        await bot.send_file(sender, ["https://ir-1.ozone.ru/s3/multimedia-g/wc1000/6846391024.jpg", 
                                     "https://ir-1.ozone.ru/s3/multimedia-p/wc1000/6813165229.jpg"])
        await event.respond("Если да, нажмите данную кнопку:", buttons=[[Button.url("Купить",paymentManager.mgr.get_order("b"))]])
    if event.raw_text=="Ботинки зимние":
        string = prices[7][2]
        await event.respond(f"Вы выбрали: Ботинки зимние \nС него вы можете получить:\n - Ботинки\n - Ботинки + одежда из раздела \"Худи\"Цена: {string} руб. Вы действительно хотите купить это?", buttons=[[button("Отмена")]])
        await bot.send_file(sender, ["https://ir-1.ozone.ru/s3/multimedia-z/wc1000/6771461567.jpg", 
                                     "https://static.rendez-vous.ru/files/catalog_models/3209028_botinki_marco_tozzi_2_2_25260_29_chernyy_iskusstvennaya_kozha.JPG"])
        await event.respond("Если да, нажмите данную кнопку:", buttons=[[Button.url("Купить",paymentManager.mgr.get_order("b"))]])
    if event.raw_text=="Толстовка":
        string = prices[8][2]
        await event.respond(f"Вы выбрали: Толстовка \nС него вы можете получить:\n - Одежда из раздела \"Худи\"\n - Толстовка\n - Толстовка + случайный предмет из раздела \"Худи\"Цена: {string} руб. Вы действительно хотите купить это?", buttons=[[button("Отмена")]])
        await bot.send_file(sender, ["https://ir-1.ozone.ru/s3/multimedia-v/wc1000/6821941603.jpg", 
                                     "https://i.imgur.com/VL5D8Su.png"])
        await event.respond("Если да, нажмите данную кнопку:", buttons=[[Button.url("Купить",paymentManager.mgr.get_order("b"))]])
    if event.raw_text=="Набор: куртка+термобельё+ботинки":
        string = prices[9][2]
        await event.respond(f"Вы выбрали: Набор: куртка+термобельё+ботинки\n!Вы получите гарантировано данный комплект! \nЦена: {string} руб. Вы действительно хотите купить это?", buttons=[[button("Отмена")]])
        await event.respond("Если да, нажмите данную кнопку:", buttons=[[Button.url("Купить",paymentManager.mgr.get_order("b"))]])
bot.run_until_disconnected()